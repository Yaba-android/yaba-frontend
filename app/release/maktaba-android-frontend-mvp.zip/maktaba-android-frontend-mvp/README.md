# maktaba-android-frontend-mvp
MVP for android maktaba project
