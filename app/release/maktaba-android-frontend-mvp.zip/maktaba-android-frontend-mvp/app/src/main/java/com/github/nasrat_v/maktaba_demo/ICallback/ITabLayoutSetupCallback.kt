package com.github.nasrat_v.maktaba_demo.ICallback

import android.support.v4.view.ViewPager

interface ITabLayoutSetupCallback {
    fun setupTabLayout(viewPager: ViewPager)
}