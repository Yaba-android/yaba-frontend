package com.github.nasrat_v.maktaba_demo.ICallback

interface IInputBrowseCallback {
    fun getInputBrowseString(): String
}