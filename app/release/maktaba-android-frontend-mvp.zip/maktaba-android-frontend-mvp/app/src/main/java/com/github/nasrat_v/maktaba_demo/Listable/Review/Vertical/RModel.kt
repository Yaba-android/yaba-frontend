package com.github.nasrat_v.maktaba_demo.Listable.Review.Vertical

data class RModel(var image: Int, var author: String, var comment: String, var rating: Float) {
}