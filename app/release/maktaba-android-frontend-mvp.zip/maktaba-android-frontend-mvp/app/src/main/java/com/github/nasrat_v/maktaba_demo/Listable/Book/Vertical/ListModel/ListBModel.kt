package com.github.nasrat_v.maktaba_demo.Listable.Book.Vertical.ListModel

import com.github.nasrat_v.maktaba_demo.Listable.Book.Horizontal.Model.BModel

data class ListBModel(var title: String, var bookModels: ArrayList<BModel>) {
}